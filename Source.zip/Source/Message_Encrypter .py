import random
import json
import os
from tkinter import messagebox, Tk, Button, Label, Frame, Entry

def create_substitution_alphabet():
    alphabet = list("qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM1234567890,./;'[]\<>?:\"{}|=-_+!@#$%^&*()~`")
    shuffled = alphabet.copy()
    random.shuffle(shuffled)
    return dict(zip(alphabet, shuffled))

def initialize_json():
    if not os.path.exists('dictionary.json'):
        with open('dictionary.json', 'w') as f:
            json.dump({"keys": {}}, f)

def save_substitution_alphabet(substitution_data, key):
    initialize_json()
    with open('dictionary.json', 'r+') as f:
        data = json.load(f)
        data["keys"][key] = substitution_data
        f.seek(0)
        json.dump(data, f, indent=4)
        f.truncate()

def load_substitution_alphabet(key):
    try:
        with open('dictionary.json', 'r') as f:
            data = json.load(f)
            return data["keys"].get(key, None)
    except FileNotFoundError:
        return None

def encrypt(message, key):
    original_message = message.lower()
    substitution_alphabet = create_substitution_alphabet()

    # Encrypt the message
    encrypted_message = ''.join(substitution_alphabet.get(char, char) for char in original_message)

    # Save the substitution data
    substitution_data = {
        'substitution': substitution_alphabet
    }
    save_substitution_alphabet(substitution_data, key)

    return encrypted_message

def decrypt(message, substitution_data):
    reversed_substitution = {v: k for k, v in substitution_data['substitution'].items()}
    
    # Decrypt the message
    decrypted_message = ''.join(reversed_substitution.get(char, char) for char in message)

    return decrypted_message

# Encryption methods
def substitution_cipher_encrypt(message):
    alphabet = list("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890`~!@#$%^&*()-=_+[]\{}|;':\",.<>/?")
    shuffled = alphabet.copy()
    random.shuffle(shuffled)
    substitution_alphabet = dict(zip(alphabet, shuffled))
    encrypted_message = ''.join(substitution_alphabet.get(char, char) for char in message)
    return encrypted_message, substitution_alphabet

def substitution_cipher_decrypt(message, substitution_alphabet):
    reversed_substitution = {v: k for k, v in substitution_alphabet.items()}
    decrypted_message = ''.join(reversed_substitution.get(char, char) for char in message)
    return decrypted_message

def reverse_cipher_encrypt(message):
    return message[::-1]

def reverse_cipher_decrypt(message):
    return message[::-1]

def encrypt(message):
    methods = [
        ("S", substitution_cipher_encrypt),
        ("R", reverse_cipher_encrypt)
    ]
    method_prefix, method_function = random.choice(methods)
    if method_prefix == "S":
        encrypted_message, substitution_alphabet = method_function(message)
        substitution_data = ''.join(f"{k}:{v}," for k, v in substitution_alphabet.items())
        return f"{method_prefix}|{substitution_data}|{encrypted_message}"
    elif method_prefix == "R":
        encrypted_message = method_function(message)
        return f"{method_prefix}|{encrypted_message}"

def decrypt(message):
    try:
        parts = message.split("|", 2)
        method_prefix = parts[0]
        if method_prefix == "S":
            substitution_data = parts[1]
            encrypted_message = parts[2]
            substitution_alphabet = dict(item.split(":") for item in substitution_data.split(",") if item)
            return substitution_cipher_decrypt(encrypted_message, substitution_alphabet)
        elif method_prefix == "R":
            encrypted_message = parts[1]
            return reverse_cipher_decrypt(encrypted_message)
        else:
            raise ValueError("Unknown encryption method.")
    except Exception as e:
        raise ValueError("Invalid encrypted message format.") from e

def encrypt_action():
    message = message_entry.get().strip()
    if message:
        encrypted = encrypt(message)
        result_label.config(text=f"Encrypted Message:\n{encrypted}")
        copy_to_clipboard(encrypted)
    else:
        messagebox.showwarning("Invalid Input", "Message must be provided.")

def decrypt_action():
    message = message_entry.get().strip()
    if message:
        try:
            decrypted = decrypt(message)
            result_label.config(text=f"Decrypted Message:\n{decrypted}")
            copy_to_clipboard(decrypted)
        except ValueError as e:
            messagebox.showinfo('ERROR', str(e))
    else:
        messagebox.showwarning("Invalid Input", "Message must be provided.")

def copy_to_clipboard(text):
    root.clipboard_clear()
    root.clipboard_append(text)
    root.update()
    messagebox.showinfo("Copied to Clipboard", "The text has been copied to the clipboard.")

root = Tk()
root.title("Message Encryptor")
root.geometry("600x500")
root.configure(bg="#1e1e1e")

frame = Frame(root, bg="#1e1e1e")
frame.pack(padx=20, pady=20)

Label(frame, text="Message Encryptor", font=("Courier New", 24), bg="#1e1e1e", fg="#00ff00").pack(pady=10)

Label(frame, text="Enter Message:", font=("Courier New", 16), bg="#1e1e1e", fg="#00ff00").pack(anchor="w")
message_entry = Entry(frame, font=("Courier New", 16), width=30, bg="#000000", fg="#00ff00")
message_entry.pack(pady=5)  

encrypt_button = Button(frame, text="Encrypt Message", command=encrypt_action, font=("Courier New", 16), bg="#4CAF50", fg="white", width=20)
encrypt_button.pack(pady=10)

decrypt_button = Button(frame, text="Decrypt Message", command=decrypt_action, font=("Courier New", 16), bg="#2196F3", fg="white", width=20)
decrypt_button.pack(pady=10)

result_label = Label(frame, text="", font=("Courier New", 16), bg="#1e1e1e", fg="#00ff00", wraplength=500, justify="left")
result_label.pack(pady=10)

root.mainloop()
